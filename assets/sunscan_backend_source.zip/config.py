# -*- coding: utf-8 -*-
"""
Created on Sat Feb  3 11:39:42 2024

@author: valer
"""

# parametrisation d'INTI
#
# lange LG=1 en FR - LG=2 en EN
LG= 1

# mode faible dynamique pour Guillaume
# Si False INTI mode normal
# Si True INTI s'adapte a faible dynamique
LowDyn=True